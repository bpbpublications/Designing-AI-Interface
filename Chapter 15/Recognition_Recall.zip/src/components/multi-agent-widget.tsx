import { AlertTriangle, CheckCircle, Clock } from 'lucide-react';

export function MultiAgentWidget() {
  const agents = [
    {
      id: 1,
      name: 'Summarizer AI',
      status: 'error',
      message: 'Draft incomplete (data missing from Verifier)',
    },
    {
      id: 2,
      name: 'Analyzer AI',
      status: 'complete',
      message: 'Analysis complete',
    },
    {
      id: 3,
      name: 'Verifier AI',
      status: 'processing',
      message: 'Processing data...',
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'error':
        return 'bg-red-500';
      case 'complete':
        return 'bg-green-500';
      case 'processing':
        return 'bg-blue-500';
      default:
        return 'bg-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'error':
        return <AlertTriangle className="w-4 h-4" />;
      case 'complete':
        return <CheckCircle className="w-4 h-4" />;
      case 'processing':
        return <Clock className="w-4 h-4" />;
      default:
        return null;
    }
  };

  return (
    <div className="w-full max-w-3xl bg-white rounded-lg shadow-sm border border-gray-200">
      {/* Header */}
      <div className="px-4 py-3 border-b border-gray-200 bg-gray-50">
        <h2 className="text-gray-900">Multi-Agent System</h2>
      </div>

      {/* Warning Banner */}
      <div className="px-4 py-3 bg-amber-50 border-b border-amber-200 flex items-center gap-3">
        <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0" />
        <div>
          <p className="text-amber-900">System Warning</p>
          <p className="text-amber-700 text-sm">One or more agents encountered an error. Please review and retry.</p>
        </div>
      </div>

      {/* Agents Grid */}
      <div className="p-4 grid grid-cols-3 gap-3">
        {agents.map((agent) => (
          <div
            key={agent.id}
            className={`p-3 rounded-lg border-2 ${
              agent.status === 'error'
                ? 'border-red-200 bg-red-50'
                : agent.status === 'complete'
                ? 'border-green-200 bg-green-50'
                : 'border-blue-200 bg-blue-50'
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              <div className={`w-8 h-8 rounded-full ${getStatusColor(agent.status)} flex items-center justify-center text-white`}>
                {getStatusIcon(agent.status)}
              </div>
              <div className="flex-1 min-w-0">
                <p className={`text-sm truncate ${
                  agent.status === 'error' ? 'text-red-900' : 
                  agent.status === 'complete' ? 'text-green-900' : 
                  'text-blue-900'
                }`}>
                  {agent.name}
                </p>
              </div>
            </div>
            <p className={`text-xs ${
              agent.status === 'error' ? 'text-red-700' : 
              agent.status === 'complete' ? 'text-green-700' : 
              'text-blue-700'
            }`}>
              {agent.message}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
