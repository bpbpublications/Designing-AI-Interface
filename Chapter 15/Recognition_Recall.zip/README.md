
  # Create Warning Widget

  This is a code bundle for Create Warning Widget. The original project is available at https://www.figma.com/design/EwcdSnmZHaRUaxP8vKYWTu/Create-Warning-Widget.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  