import { Bot, Clock } from 'lucide-react';

export function NotesEditor() {
  return (
    <div className="p-6">
      <div className="mb-4">
        <h2 className="text-gray-700">DOCTOR'S NOTES (AI-ASSISTED)</h2>
      </div>

      <div className="space-y-4">
        {/* AI Generated Summary */}
        <div className="bg-[#e3f2fd] border-l-4 border-[#1976d2] p-4 rounded">
          <div className="flex items-start gap-2 mb-2">
            <Bot size={16} className="text-[#1976d2] mt-0.5" />
            <span className="text-sm text-[#1976d2]">AI Added summary:</span>
          </div>
          <p className="text-gray-800 ml-6">
            "Patient shows signs of mild asthma with recommendation for inhaler dose increase."
          </p>
        </div>

        {/* User Edit Timestamp */}
        <div className="flex items-center gap-2 text-sm text-gray-600 px-4">
          <Clock size={14} />
          <span>You edited this text 2 min ago</span>
        </div>

        {/* User Notes */}
        <div className="bg-gray-50 border-l-4 border-gray-400 p-4 rounded">
          <div className="text-gray-600 text-sm mb-2">&gt;&gt;</div>
          <p className="text-gray-800">
            Patient reports occasional wheezing.
            <br />
            No change in medication yet. Monitoring advised.
          </p>
        </div>
      </div>
    </div>
  );
}