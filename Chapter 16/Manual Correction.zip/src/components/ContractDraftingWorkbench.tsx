import { useState } from 'react';
import { Scale, Shield, BarChart3, Sparkles, AlertCircle, Copy, Edit3 } from 'lucide-react';

type Mode = 'safe' | 'balanced' | 'creative';

export function ContractDraftingWorkbench() {
  const [selectedMode, setSelectedMode] = useState<Mode>('safe');
  const [showComparison, setShowComparison] = useState(false);

  const modeConfig = {
    safe: {
      icon: Shield,
      color: '#10b981',
      bg: '#059669',
      title: 'Safe',
      subtitle: 'Conservative'
    },
    balanced: {
      icon: BarChart3,
      color: '#3b82f6',
      bg: '#2563eb',
      title: 'Balanced',
      subtitle: 'Flexible'
    },
    creative: {
      icon: Sparkles,
      color: '#a855f7',
      bg: '#9333ea',
      title: 'Creative',
      subtitle: 'Innovative'
    }
  };

  const generatedClauses = {
    safe: "The Receiving Party shall hold and maintain the Confidential Information in strict confidence for the sole and exclusive benefit of the Disclosing Party. The Receiving Party shall not, without prior written approval of the Disclosing Party, use for its own benefit, publish, copy, or otherwise disclose to others, or permit the use by others for their benefit or to the detriment of the Disclosing Party, any Confidential Information.",
    balanced: "The Receiving Party agrees to maintain the confidentiality of all Confidential Information disclosed by the Disclosing Party and shall not disclose such information to third parties without prior written consent, except as required by law or to employees who need to know such information for legitimate business purposes.",
    creative: "Each party acknowledges that disclosed information constitutes valuable trade secrets and proprietary knowledge. Both parties commit to establishing reasonable safeguards appropriate to the sensitivity level of each disclosure, with mutual understanding that protection measures may evolve based on the nature of collaboration and information shared."
  };

  const currentMode = modeConfig[selectedMode];

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Compact Header */}
      <header className="bg-black border-b-2 border-yellow-400">
        <div className="max-w-[1800px] mx-auto px-4 py-2 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-yellow-400 p-1.5 rounded">
              <Scale className="text-black" size={18} />
            </div>
            <div>
              <h1 className="text-white text-sm">Contract Drafting Workbench</h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs px-2 py-1 bg-yellow-400 text-black rounded">CDW-2847</span>
            <span className="text-xs px-2 py-1 bg-gray-700 text-white rounded">Mutual NDA</span>
          </div>
        </div>
      </header>

      <div className="max-w-[1800px] mx-auto px-4 py-4">
        <div className="grid grid-cols-12 gap-4">
          {/* Left Section - Mode Selection */}
          <div className="col-span-3 space-y-2">
            <div className="bg-gray-800 border border-gray-700 rounded p-3">
              <h3 className="text-white text-xs mb-2">AI MODE</h3>
              <div className="space-y-1.5">
                {(Object.keys(modeConfig) as Mode[]).map((mode) => {
                  const config = modeConfig[mode];
                  const Icon = config.icon;
                  const isSelected = selectedMode === mode;
                  
                  return (
                    <button
                      key={mode}
                      onClick={() => setSelectedMode(mode)}
                      className={`w-full flex items-center gap-2 p-2 rounded transition-all text-left ${
                        isSelected
                          ? 'text-black'
                          : 'bg-gray-900 text-gray-300 hover:bg-gray-700'
                      }`}
                      style={isSelected ? { backgroundColor: config.color } : {}}
                    >
                      <Icon size={16} />
                      <div className="flex-1">
                        <div className="text-xs">{config.title}</div>
                        <div className="text-[10px] opacity-80">{config.subtitle}</div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Risk Level */}
            <div className="bg-gray-800 border border-gray-700 rounded p-3">
              <h3 className="text-white text-xs mb-2">RISK LEVEL</h3>
              <div className="flex gap-1">
                <button className="flex-1 text-[10px] px-2 py-1.5 bg-green-600 text-white rounded hover:bg-green-700">
                  Low
                </button>
                <button className="flex-1 text-[10px] px-2 py-1.5 bg-amber-600 text-white rounded hover:bg-amber-700">
                  Mid
                </button>
                <button className="flex-1 text-[10px] px-2 py-1.5 bg-gray-700 text-gray-400 rounded hover:bg-red-600 hover:text-white">
                  High
                </button>
              </div>
            </div>

            {/* Template */}
            <div className="bg-gray-800 border border-gray-700 rounded p-3">
              <h3 className="text-white text-xs mb-2">TEMPLATE</h3>
              <div className="text-[11px] text-gray-300 mb-2">Industry-standard mutual NDA</div>
              <button className="text-[10px] text-cyan-400 hover:text-cyan-300">
                Change template →
              </button>
            </div>
          </div>

          {/* Middle Section - Generated Clause */}
          <div className="col-span-6">
            <div className="bg-gray-800 border-2 rounded h-full flex flex-col" style={{ borderColor: currentMode.color }}>
              <div className="flex items-center justify-between px-4 py-2 border-b" style={{ 
                backgroundColor: currentMode.bg,
                borderColor: currentMode.color 
              }}>
                <div className="flex items-center gap-2">
                  <h3 className="text-white text-sm">Generated Confidentiality Clause</h3>
                  <span className="text-xs px-2 py-0.5 bg-black bg-opacity-30 text-white rounded">
                    {currentMode.title} Mode
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-1.5 bg-black bg-opacity-30 hover:bg-opacity-50 text-white rounded transition-colors">
                    <Copy size={14} />
                  </button>
                  <button className="p-1.5 bg-black bg-opacity-30 hover:bg-opacity-50 text-white rounded transition-colors">
                    <Edit3 size={14} />
                  </button>
                </div>
              </div>
              
              <div className="flex-1 p-4 bg-gray-900">
                <p className="text-gray-100 text-sm leading-relaxed">
                  {generatedClauses[selectedMode]}
                </p>
              </div>

              <div className="px-4 py-2 bg-gray-950 border-t border-gray-700 flex items-center justify-between">
                <div className="flex items-center gap-3 text-xs">
                  <span className="text-green-400">● Confidence: 94%</span>
                  <span className="text-gray-500">|</span>
                  <span className="text-gray-400">247 similar agreements</span>
                </div>
                <button 
                  onClick={() => setShowComparison(!showComparison)}
                  className="text-xs text-cyan-400 hover:text-cyan-300"
                >
                  {showComparison ? 'Hide' : 'Show'} comparison →
                </button>
              </div>
            </div>
          </div>

          {/* Right Section - Actions & Details */}
          <div className="col-span-3 space-y-2">
            {/* Mode Details */}
            <div className="bg-gray-800 border rounded p-3" style={{ borderColor: currentMode.color }}>
              <div className="flex items-center gap-2 mb-2">
                <div className="p-1.5 rounded" style={{ backgroundColor: currentMode.color }}>
                  {(() => {
                    const Icon = currentMode.icon;
                    return <Icon size={14} className="text-black" />;
                  })()}
                </div>
                <h3 className="text-white text-xs">{currentMode.title.toUpperCase()} MODE</h3>
              </div>
              <div className="space-y-1.5 text-[11px] text-gray-300">
                {selectedMode === 'safe' && (
                  <>
                    <div className="flex items-start gap-1.5">
                      <span className="text-green-400 mt-0.5">✓</span>
                      <span>Maximum legal protection</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <span className="text-green-400 mt-0.5">✓</span>
                      <span>Industry-standard language</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <span className="text-green-400 mt-0.5">✓</span>
                      <span>Court-tested provisions</span>
                    </div>
                  </>
                )}
                {selectedMode === 'balanced' && (
                  <>
                    <div className="flex items-start gap-1.5">
                      <span className="text-blue-400 mt-0.5">✓</span>
                      <span>Reasonable protections</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <span className="text-blue-400 mt-0.5">✓</span>
                      <span>Business-friendly terms</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <span className="text-blue-400 mt-0.5">✓</span>
                      <span>Negotiation-ready language</span>
                    </div>
                  </>
                )}
                {selectedMode === 'creative' && (
                  <>
                    <div className="flex items-start gap-1.5">
                      <span className="text-purple-400 mt-0.5">✓</span>
                      <span>Novel clause structures</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <span className="text-purple-400 mt-0.5">✓</span>
                      <span>Adaptive provisions</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <span className="text-purple-400 mt-0.5">✓</span>
                      <span>Custom-tailored language</span>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Actions */}
            <div className="bg-gray-800 border border-gray-700 rounded p-3">
              <h3 className="text-white text-xs mb-2">ACTIONS</h3>
              <div className="space-y-1.5">
                <button className="w-full text-xs px-3 py-2 bg-yellow-400 text-black rounded hover:bg-yellow-500 transition-colors">
                  Apply to Document
                </button>
                <button className="w-full text-xs px-3 py-2 bg-gray-700 text-white rounded hover:bg-gray-600 transition-colors">
                  Edit Manually
                </button>
                <button className="w-full text-xs px-3 py-2 bg-gray-900 text-gray-300 rounded hover:bg-gray-700 transition-colors border border-gray-700">
                  Regenerate Clause
                </button>
              </div>
            </div>

            {/* Alert */}
            <div className="bg-blue-950 border border-blue-700 rounded p-3">
              <div className="flex gap-2">
                <AlertCircle size={14} className="text-blue-400 flex-shrink-0 mt-0.5" />
                <div className="text-[10px] text-blue-200">
                  AI-generated clauses should be reviewed by legal counsel before use.
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Comparison View */}
        {showComparison && (
          <div className="mt-4 bg-gray-800 border border-gray-700 rounded p-4">
            <h4 className="text-white text-xs mb-3">VERSION COMPARISON</h4>
            <div className="grid grid-cols-3 gap-3">
              {(Object.keys(modeConfig) as Mode[]).map((mode) => {
                const config = modeConfig[mode];
                return (
                  <div key={mode} className="border rounded overflow-hidden" style={{ borderColor: config.color }}>
                    <div className="px-3 py-1.5 text-white text-xs" style={{ backgroundColor: config.bg }}>
                      {config.title}
                    </div>
                    <div className="p-3 bg-gray-900 text-[11px] text-gray-300 leading-relaxed">
                      {generatedClauses[mode]}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
