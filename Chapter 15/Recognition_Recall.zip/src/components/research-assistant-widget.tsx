import { Edit3, BookOpen, FileText, Quote, Sparkles, Shield, Link } from 'lucide-react';

export function ResearchAssistantWidget() {
  return (
    <div className="w-full max-w-3xl bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 bg-gradient-to-r from-purple-500 to-pink-600 flex items-center gap-3">
        <div className="w-8 h-8 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center">
          <Edit3 className="w-4 h-4 text-white" />
        </div>
        <h2 className="text-white">Research Assistant</h2>
        <span className="px-2 py-0.5 bg-white/20 backdrop-blur-sm rounded text-xs text-white">Beta</span>
      </div>

      {/* Content */}
      <div className="px-4 py-4 space-y-4">
        {/* Capabilities */}
        <div className="flex items-start gap-3 bg-emerald-50 rounded-lg p-3 border-l-4 border-emerald-500">
          <Sparkles className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-gray-900">
              <span className="text-emerald-700">I can:</span> find sources • extract quotes • draft related <span className="text-purple-600">work</span> sections
            </p>
          </div>
        </div>

        {/* Limitations */}
        <div className="flex items-start gap-3 bg-red-50 rounded-lg p-3 border-l-4 border-red-500">
          <Shield className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-gray-900">
              <span className="text-red-700">I cannot:</span> <span className="text-purple-600">access</span> paywalled content <span className="text-purple-600">without</span> credentials • judge legal risk
            </p>
          </div>
        </div>

        {/* Task */}
        <div className="bg-blue-50 rounded-lg p-3 border-l-4 border-blue-500">
          <div className="flex items-start gap-3">
            <FileText className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-blue-700 mb-1">Task</p>
              <p className="text-gray-900">"Create a related-work paragraph about WoZ studies in HCI."</p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap pt-2">
          <button className="px-4 py-2 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white rounded-lg flex items-center gap-2 transition-all shadow-sm">
            <BookOpen className="w-4 h-4" />
            Get Sources
          </button>
          <button className="px-4 py-2 bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white rounded-lg flex items-center gap-2 transition-all shadow-sm">
            <FileText className="w-4 h-4" />
            Draft Paragraph
          </button>
          <button className="px-4 py-2 bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white rounded-lg flex items-center gap-2 transition-all shadow-sm">
            <Quote className="w-4 h-4" />
            Cite in APA
          </button>
        </div>

        {/* Tip */}
        <div className="bg-amber-50 rounded-lg p-3 border border-amber-200">
          <p className="text-sm text-gray-700">
            <span className="text-amber-700">💡 Tip:</span> Treat me <span className="text-purple-600">like</span> a junior analyst—review my <span className="text-purple-600">work before</span> publishing.
          </p>
        </div>
      </div>
    </div>
  );
}
