import { FileText, Pause, X, FileCode } from 'lucide-react';

export function SummarizationWidget() {
  const progress = 52;
  const confidence = 78;

  return (
    <div className="w-full max-w-2xl bg-white rounded-lg shadow-lg border border-gray-200">
      {/* Header */}
      <div className="px-5 py-4 border-b border-gray-200 bg-gradient-to-r from-blue-500 to-purple-600 rounded-t-lg flex items-center gap-3">
        <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center">
          <FileText className="w-5 h-5 text-white" />
        </div>
        <span className="text-white">Summarization in Progress</span>
      </div>

      {/* Content */}
      <div className="px-5 py-5 space-y-4">
        {/* Status with Progress Bar */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-gray-700">Analyzing 3 documents...</span>
            <span className="text-purple-600">{progress}%</span>
          </div>
          <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-blue-500 to-purple-600 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Current Step */}
        <div className="bg-gray-50 rounded-lg p-4 space-y-2">
          <div className="flex items-start gap-2">
            <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 animate-pulse" />
            <div className="flex-1">
              <p className="text-gray-900">
                Current step: Extracting headings from <span className="text-purple-600">"03_Report.pdf"</span>
              </p>
            </div>
          </div>
          <div className="pl-4 space-y-1">
            <p className="text-sm text-gray-600">
              ETA: <span className="text-orange-600">~18s</span>
            </p>
            <div className="flex items-center gap-2">
              <p className="text-sm text-gray-600">Confidence so far:</p>
              <div className="flex items-center gap-2">
                <div className="h-2 w-24 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-green-500 to-emerald-500 rounded-full"
                    style={{ width: `${confidence}%` }}
                  />
                </div>
                <span className="text-sm text-emerald-600">{confidence}%</span>
              </div>
              <span className="text-xs text-amber-600 bg-amber-50 px-2 py-1 rounded">may need review</span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="px-5 py-4 border-t border-gray-200 bg-gray-50 rounded-b-lg flex items-center gap-3">
        <button className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-lg flex items-center gap-2 transition-colors">
          <Pause className="w-4 h-4" />
          Pause
        </button>
        <button className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg flex items-center gap-2 transition-colors">
          <X className="w-4 h-4" />
          Cancel
        </button>
        <button className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg flex items-center gap-2 transition-colors ml-auto">
          <FileCode className="w-4 h-4" />
          View Logs
        </button>
      </div>
    </div>
  );
}