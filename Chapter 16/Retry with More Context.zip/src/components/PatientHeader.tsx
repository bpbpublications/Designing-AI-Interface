import { Sparkles } from 'lucide-react';

interface PatientHeaderProps {
  patientName: string;
  visitDate: string;
}

export function PatientHeader({ patientName, visitDate }: PatientHeaderProps) {
  return (
    <div className="bg-[#1976d2] text-white px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-8">
          <div>
            <div className="text-sm opacity-90">PATIENT</div>
            <div className="mt-1">{patientName}</div>
          </div>
          <div>
            <div className="text-sm opacity-90">VISIT</div>
            <div className="mt-1">{visitDate}</div>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-white/20 px-3 py-1.5 rounded">
          <Sparkles size={16} />
          <span className="text-sm">EHR AI</span>
        </div>
      </div>
    </div>
  );
}
