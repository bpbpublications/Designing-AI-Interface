import { ProductContentStudio } from './components/ProductContentStudio';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <ProductContentStudio />
    </div>
  );
}
