import { useState } from 'react';
import { Scale, Shield, BarChart3, Sparkles } from 'lucide-react';

export function ContractDraftingWorkbench() {
  const [selectedMode, setSelectedMode] = useState<'safe' | 'balanced' | 'creative'>('safe');

  return (
    <div className="max-w-5xl mx-auto bg-white rounded-lg border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="bg-slate-800 px-6 py-3 flex items-center justify-between text-white">
        <h1>Contract Drafting Workbench</h1>
        <div className="flex items-center gap-2 bg-slate-700 px-3 py-1.5 rounded">
          <span className="text-sm">Legal AI</span>
          <Scale size={16} />
        </div>
      </div>

      {/* Agreement Type */}
      <div className="px-6 py-3 bg-slate-50 border-b border-gray-200">
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-600">AGREEMENT TYPE</span>
          <span className="text-gray-900">Vendor NDA</span>
        </div>
      </div>

      {/* AI Behavior Mode */}
      <div className="px-6 py-5 border-b border-gray-200">
        <h2 className="text-gray-900 mb-4">AI Behavior Mode</h2>
        
        <div className="grid grid-cols-3 gap-4">
          <button
            onClick={() => setSelectedMode('safe')}
            className={`border-2 rounded-lg p-4 transition-all ${
              selectedMode === 'safe'
                ? 'border-emerald-500 bg-emerald-50'
                : 'border-gray-200 bg-white hover:border-gray-300'
            }`}
          >
            <div className="flex items-center justify-center mb-2">
              <Shield size={24} className={selectedMode === 'safe' ? 'text-emerald-600' : 'text-gray-400'} />
            </div>
            <div className={`text-center mb-1 ${selectedMode === 'safe' ? 'text-gray-900' : 'text-gray-700'}`}>
              Safe & Conservative
            </div>
            <div className="text-xs text-center text-emerald-600">
              (Recommended)
            </div>
          </button>
          
          <button
            onClick={() => setSelectedMode('balanced')}
            className={`border-2 rounded-lg p-4 transition-all ${
              selectedMode === 'balanced'
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 bg-white hover:border-gray-300'
            }`}
          >
            <div className="flex items-center justify-center mb-2">
              <BarChart3 size={24} className={selectedMode === 'balanced' ? 'text-blue-600' : 'text-gray-400'} />
            </div>
            <div className={`text-center mb-1 ${selectedMode === 'balanced' ? 'text-gray-900' : 'text-gray-700'}`}>
              Balanced
            </div>
            <div className="text-xs text-center text-blue-600">
              (More flexible)
            </div>
          </button>
          
          <button
            onClick={() => setSelectedMode('creative')}
            className={`border-2 rounded-lg p-4 transition-all ${
              selectedMode === 'creative'
                ? 'border-purple-500 bg-purple-50'
                : 'border-gray-200 bg-white hover:border-gray-300'
            }`}
          >
            <div className="flex items-center justify-center mb-2">
              <Sparkles size={24} className={selectedMode === 'creative' ? 'text-purple-600' : 'text-gray-400'} />
            </div>
            <div className={`text-center ${selectedMode === 'creative' ? 'text-gray-900' : 'text-gray-700'}`}>
              Creative
            </div>
          </button>
        </div>
      </div>

      {/* Current Mode Description */}
      <div className="px-6 py-5 bg-emerald-50 border-b border-emerald-100">
        <div className="flex items-center gap-2 mb-3">
          <Shield size={18} className="text-emerald-600" />
          <h3 className="text-gray-900">Current Mode: Safe & Conservative</h3>
        </div>
        
        <div className="text-gray-700 mb-2">Description:</div>
        <ul className="space-y-1.5 text-gray-800">
          <li className="flex items-start gap-2">
            <span className="text-emerald-600 mt-0.5">•</span>
            <span>Prioritizes enforceability</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-emerald-600 mt-0.5">•</span>
            <span>Uses standard clauses</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-emerald-600 mt-0.5">•</span>
            <span>Minimizes ambiguous wording</span>
          </li>
        </ul>
      </div>

      {/* Key Clause */}
      <div className="px-6 py-5 border-b border-gray-200">
        <div className="text-gray-900 mb-3">Key Clause (Generated)</div>
        
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
          <div className="font-mono text-sm text-gray-800 leading-relaxed">
            The Receiving Party shall not disclose Confidential Information to any third party without prior written consent of the Disclosing Party.
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="px-6 py-4 flex items-center gap-3">
        <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors">
          Switch to Balanced mode and revise clause
        </button>
        <button className="bg-white text-gray-700 px-4 py-2 rounded border border-gray-300 hover:bg-gray-50 transition-colors">
          Keep as is
        </button>
        <button className="bg-white text-gray-700 px-4 py-2 rounded border border-gray-300 hover:bg-gray-50 transition-colors">
          Show comparison of 3 versions
        </button>
      </div>
    </div>
  );
}
