import { SummaryReportWidget } from './components/summary-report-widget';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <SummaryReportWidget />
    </div>
  );
}
