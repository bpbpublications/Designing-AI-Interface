import { Bot, User, Lightbulb } from 'lucide-react';

export function ProjectCopilot() {
  const agents = [
    { name: 'Planner AI', role: 'creates task & budget breakdowns', color: 'bg-blue-500' },
    { name: 'Summarizer AI', role: 'writes short summaries', color: 'bg-purple-500' },
    { name: 'Verifier AI', role: 'checks numbers & inconsistencies', color: 'bg-emerald-500' },
  ];

  return (
    <div className="w-full max-w-3xl bg-white rounded-lg shadow-lg border border-gray-200">
      {/* Header */}
      <div className="px-4 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-t-lg flex items-center gap-2">
        <Bot className="w-5 h-5 text-white" />
        <h1 className="text-white">Project Copilot — Multi-Agent View</h1>
      </div>

      {/* Agents Section */}
      <div className="px-4 py-3 border-b border-gray-200 bg-gray-50">
        <h2 className="text-gray-900 mb-2">Agents</h2>
        <div className="space-y-1.5">
          {agents.map((agent, index) => (
            <div key={index} className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${agent.color}`} />
              <span className="text-gray-800">
                [{agent.name}]
              </span>
              <span className="text-gray-600">
                Role: {agent.role}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Conversation Section */}
      <div className="px-4 py-4 space-y-4">
        <h2 className="text-gray-900">Conversation</h2>

        {/* User Message */}
        <div className="space-y-2">
          <div className="flex items-start gap-2">
            <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
              <User className="w-3.5 h-3.5 text-white" />
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-1">You:</p>
              <p className="text-gray-900">"Create a budget breakdown for the Q3 marketing plan."</p>
            </div>
          </div>
        </div>

        {/* AI Response */}
        <div className="space-y-2">
          <div className="flex items-start gap-2">
            <div className="w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
              <Bot className="w-3.5 h-3.5 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-gray-600 mb-1">[Summarizer AI]:</p>
              <div className="bg-purple-50 rounded-lg p-3 border-l-4 border-purple-500">
                <p className="text-gray-900 mb-2">"Here's a brief summary of your Q3 marketing budget:</p>
                <ul className="space-y-1 text-gray-900 list-disc list-inside">
                  <li>Overall spend is projected at $120K</li>
                  <li>Major categories: Ads, Events, Content, Tools</li>
                  <li>Spend is higher than last quarter due to new product launch."</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* User Thinking */}
        <div className="bg-blue-50 rounded-lg p-3 border-l-4 border-blue-400">
          <p className="text-sm text-blue-700 mb-1">You (thinking):</p>
          <p className="text-gray-800 italic">"I wanted a detailed breakdown, not just a summary... Did I ask the wrong AI?"</p>
        </div>

        {/* System Hint */}
        <div className="bg-amber-50 rounded-lg p-3 border-l-4 border-amber-400 flex items-start gap-2">
          <Lightbulb className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-xs text-amber-700 mb-1">Hint (system message, subtle):</p>
            <p className="text-sm text-gray-800">"Need line-item details? Ask Planner AI: 'Break this into categories and items'"</p>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-4 py-3 border-t border-gray-200 bg-gray-50 rounded-b-lg">
        <p className="text-sm text-gray-700 mb-2">Quick Actions</p>
        <div className="flex items-center gap-2 flex-wrap">
          <button className="px-3 py-1.5 bg-blue-500 hover:bg-blue-600 text-white rounded text-sm transition-colors">
            [ Ask Planner AI for detailed breakdown ]
          </button>
          <button className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded text-sm transition-colors">
            [ Accept Summary ]
          </button>
          <button className="px-3 py-1.5 bg-purple-500 hover:bg-purple-600 text-white rounded text-sm transition-colors">
            [ Provide Feedback ]
          </button>
        </div>
      </div>
    </div>
  );
}
