import { useState } from 'react';
import { User, Sparkles, Info } from 'lucide-react';

export function TalentScreeningConsole() {
  const [region, setRegion] = useState('India');
  const [minYears, setMinYears] = useState('8+');
  const [limitCandidates, setLimitCandidates] = useState('30');
  const [skills, setSkills] = useState({
    roadmapping: true,
    stakeholder: true,
    deepData: false,
    coding: false
  });

  return (
    <div className="max-w-5xl mx-auto">
      <div className="bg-white/80 backdrop-blur-xl rounded-3xl shadow-2xl overflow-hidden border border-white/50">
        {/* Header with gradient */}
        <div className="bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-600 px-6 py-4">
          <div className="flex items-center justify-between text-white">
            <div className="flex items-center gap-3">
              <div className="bg-white/20 backdrop-blur-sm p-2 rounded-xl">
                <Sparkles size={20} />
              </div>
              <span className="text-lg">Talent Screening Console</span>
            </div>
            <div className="flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full">
              <span>HR AI</span>
              <User size={18} />
            </div>
          </div>
        </div>

        {/* Role & Task */}
        <div className="bg-gradient-to-r from-purple-50 to-blue-50 px-6 py-3 border-b border-gray-200">
          <div className="flex gap-8">
            <div>
              <span className="text-purple-600 text-sm">ROLE:</span>
              <span className="ml-2 text-gray-800">Senior Product Manager</span>
            </div>
            <div>
              <span className="text-blue-600 text-sm">AI TASK:</span>
              <span className="ml-2 text-gray-800">Shortlist top 20 candidates from 520 profiles</span>
            </div>
          </div>
        </div>

        {/* Current Scope */}
        <div className="px-6 py-4 bg-gradient-to-br from-white to-gray-50">
          <div className="text-sm text-gray-600 mb-3">CURRENT SCOPE</div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-4 text-white shadow-lg">
              <div className="space-y-1.5">
                <div className="flex justify-between">
                  <span className="opacity-90">Candidates</span>
                  <span className="font-semibold">520</span>
                </div>
                <div className="flex justify-between">
                  <span className="opacity-90">Region</span>
                  <span className="font-semibold">Any</span>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl p-4 text-white shadow-lg">
              <div className="space-y-1.5">
                <div className="flex justify-between">
                  <span className="opacity-90">Experience</span>
                  <span className="font-semibold">4–20 yrs</span>
                </div>
                <div className="flex justify-between">
                  <span className="opacity-90">Skills</span>
                  <span className="font-semibold">Product, UX, Data, Domain</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Narrow Scope */}
        <div className="px-6 py-4 bg-white border-t border-gray-200">
          <div className="text-sm text-gray-600 mb-3">NARROW THE SCOPE BEFORE NEXT AI RUN</div>
          
          <div className="grid grid-cols-2 gap-6">
            {/* Left Column */}
            <div className="space-y-3">
              <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-xl p-3 shadow-sm">
                <label className="block text-sm text-gray-700 mb-2">Region</label>
                <select 
                  value={region} 
                  onChange={(e) => setRegion(e.target.value)}
                  className="w-full bg-white border-2 border-purple-200 rounded-lg px-3 py-2 shadow-sm focus:border-purple-400 focus:outline-none"
                >
                  <option>India</option>
                  <option>APAC</option>
                  <option>Any</option>
                </select>
              </div>
              
              <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl p-3 shadow-sm">
                <label className="block text-sm text-gray-700 mb-2">Minimum Years</label>
                <select 
                  value={minYears} 
                  onChange={(e) => setMinYears(e.target.value)}
                  className="w-full bg-white border-2 border-blue-200 rounded-lg px-3 py-2 shadow-sm focus:border-blue-400 focus:outline-none"
                >
                  <option>8+ yrs</option>
                  <option>5+ yrs</option>
                  <option>10+ yrs</option>
                </select>
              </div>

              <div className="bg-gradient-to-r from-indigo-50 to-indigo-100 rounded-xl p-3 shadow-sm">
                <label className="block text-sm text-gray-700 mb-2">Limit AI selection to</label>
                <div className="flex items-center gap-2">
                  <select 
                    value={limitCandidates} 
                    onChange={(e) => setLimitCandidates(e.target.value)}
                    className="flex-1 bg-white border-2 border-indigo-200 rounded-lg px-3 py-2 shadow-sm focus:border-indigo-400 focus:outline-none"
                  >
                    <option>30</option>
                    <option>20</option>
                    <option>50</option>
                  </select>
                  <span className="text-gray-600 text-sm">candidates</span>
                </div>
              </div>
            </div>

            {/* Right Column */}
            <div className="bg-gradient-to-br from-pink-50 via-purple-50 to-blue-50 rounded-xl p-4 shadow-sm">
              <div className="text-sm text-gray-700 mb-3">Must-have skills</div>
              <div className="space-y-2">
                <label className="flex items-center gap-3 bg-white/70 backdrop-blur-sm rounded-lg p-2.5 cursor-pointer hover:bg-white transition-colors shadow-sm">
                  <input 
                    type="checkbox" 
                    checked={skills.roadmapping}
                    onChange={(e) => setSkills({...skills, roadmapping: e.target.checked})}
                    className="w-5 h-5 accent-purple-600"
                  />
                  <span className="text-gray-800">Roadmapping</span>
                </label>
                <label className="flex items-center gap-3 bg-white/70 backdrop-blur-sm rounded-lg p-2.5 cursor-pointer hover:bg-white transition-colors shadow-sm">
                  <input 
                    type="checkbox" 
                    checked={skills.stakeholder}
                    onChange={(e) => setSkills({...skills, stakeholder: e.target.checked})}
                    className="w-5 h-5 accent-blue-600"
                  />
                  <span className="text-gray-800">Stakeholder Management</span>
                </label>
                <label className="flex items-center gap-3 bg-white/70 backdrop-blur-sm rounded-lg p-2.5 cursor-pointer hover:bg-white transition-colors shadow-sm">
                  <input 
                    type="checkbox" 
                    checked={skills.deepData}
                    onChange={(e) => setSkills({...skills, deepData: e.target.checked})}
                    className="w-5 h-5 accent-indigo-600"
                  />
                  <span className="text-gray-800">Deep Data Science</span>
                </label>
                <label className="flex items-center gap-3 bg-white/70 backdrop-blur-sm rounded-lg p-2.5 cursor-pointer hover:bg-white transition-colors shadow-sm">
                  <input 
                    type="checkbox" 
                    checked={skills.coding}
                    onChange={(e) => setSkills({...skills, coding: e.target.checked})}
                    className="w-5 h-5 accent-pink-600"
                  />
                  <span className="text-gray-800">Coding</span>
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="px-6 py-4 bg-gradient-to-r from-gray-50 to-white border-t border-gray-200">
          <div className="flex items-center gap-4">
            <button className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 text-white px-6 py-3 rounded-xl shadow-lg hover:shadow-xl hover:from-purple-700 hover:to-blue-700 transition-all">
              Narrow & Re-run Shortlist
            </button>
            <button className="flex-1 bg-white border-2 border-gray-300 text-gray-700 px-6 py-3 rounded-xl shadow-sm hover:shadow-md hover:border-gray-400 transition-all">
              Keep Full Wide Search
            </button>
          </div>
        </div>

        {/* Tip */}
        <div className="px-6 py-3 bg-gradient-to-r from-blue-50 to-purple-50 flex items-center gap-2 text-gray-700">
          <div className="bg-blue-500 text-white rounded-full p-1">
            <Info size={14} />
          </div>
          <span className="text-sm">Tip: Narrowing scope reduces noisy or irrelevant picks.</span>
        </div>
      </div>
    </div>
  );
}
