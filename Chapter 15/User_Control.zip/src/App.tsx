import { GenerationControlsWidget } from './components/generation-controls-widget';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <GenerationControlsWidget />
    </div>
  );
}
