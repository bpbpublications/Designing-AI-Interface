import { useState } from 'react';

export function RetrySection() {
  const [checkedItems, setCheckedItems] = useState({
    statements: true,
    collateral: true,
    credit: false
  });

  const [notes, setNotes] = useState('Client has strong seasonal business. Revenue dips\nin Q1 but recovers sharply by Q3.');

  const handleCheckboxChange = (key: 'statements' | 'collateral' | 'credit') => {
    setCheckedItems(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="p-6 bg-white">
      <h2 className="text-gray-800 mb-3">HELP THE AI RETRY WITH MORE CONTEXT</h2>
      
      <div className="mb-4">
        <p className="text-gray-800 mb-2">Add missing details:</p>
        
        <div className="space-y-1.5 mb-4">
          <label className="flex items-center gap-2 text-gray-800">
            <input
              type="checkbox"
              checked={checkedItems.statements}
              onChange={() => handleCheckboxChange('statements')}
              className="w-4 h-4"
            />
            Last 3 years audited statements
          </label>
          
          <label className="flex items-center gap-2 text-gray-800">
            <input
              type="checkbox"
              checked={checkedItems.collateral}
              onChange={() => handleCheckboxChange('collateral')}
              className="w-4 h-4"
            />
            Existing collateral details
          </label>
          
          <label className="flex items-center gap-2 text-gray-800">
            <input
              type="checkbox"
              checked={checkedItems.credit}
              onChange={() => handleCheckboxChange('credit')}
              className="w-4 h-4"
            />
            Owner credit score notes
          </label>
        </div>
      </div>

      <div>
        <p className="text-gray-800 mb-2">Extra notes for AI:</p>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="w-full border border-gray-400 p-2 text-gray-800 font-mono text-sm"
          rows={3}
        />
      </div>
    </div>
  );
}
