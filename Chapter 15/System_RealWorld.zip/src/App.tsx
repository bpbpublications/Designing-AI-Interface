import { ResearchAssistantWidget } from './components/research-assistant-widget';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <ResearchAssistantWidget />
    </div>
  );
}
