import { SummarizationWidget } from './components/summarization-widget';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <SummarizationWidget />
    </div>
  );
}
