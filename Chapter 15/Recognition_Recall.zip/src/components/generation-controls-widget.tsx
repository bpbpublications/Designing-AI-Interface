import { Sliders, RotateCcw, RefreshCw, Sparkles, Square, Undo } from 'lucide-react';
import { useState } from 'react';

export function GenerationControlsWidget() {
  const [creativity, setCreativity] = useState(50);
  const [useOnlyPdf, setUseOnlyPdf] = useState(true);
  const [includeExternal, setIncludeExternal] = useState(false);

  return (
    <div className="w-full max-w-2xl bg-white rounded-lg shadow-lg border border-gray-200">
      {/* Header */}
      <div className="px-4 py-3 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-t-lg flex items-center gap-3">
        <div className="w-8 h-8 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center">
          <Sliders className="w-4 h-4 text-white" />
        </div>
        <h2 className="text-white">Generation Controls</h2>
      </div>

      {/* Content */}
      <div className="px-4 py-4 space-y-4">
        {/* Creativity Slider */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-gray-900">Creativity:</label>
            <span className="text-xs text-gray-500 italic">
              (Lower = precise, Higher = varied)
            </span>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            value={creativity}
            onChange={(e) => setCreativity(Number(e.target.value))}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-500"
          />
        </div>

        {/* Constraints */}
        <div className="space-y-2">
          <label className="text-gray-900">Constraints:</label>
          <div className="space-y-2 pl-2">
            <label className="flex items-center gap-2 cursor-pointer group">
              <input
                type="checkbox"
                checked={useOnlyPdf}
                onChange={(e) => setUseOnlyPdf(e.target.checked)}
                className="w-4 h-4 accent-indigo-500 cursor-pointer"
              />
              <span className="text-gray-700">
                Use <span className="text-rose-600">only</span> data <span className="text-rose-600">from</span> <span className="text-purple-600">"03_Report.pdf"</span>
              </span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer group">
              <input
                type="checkbox"
                checked={includeExternal}
                onChange={(e) => setIncludeExternal(e.target.checked)}
                className="w-4 h-4 accent-indigo-500 cursor-pointer"
              />
              <span className="text-gray-700">
                Include <span className="text-rose-600">external</span> web facts
              </span>
            </label>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap pt-2">
          <button className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white rounded-lg flex items-center gap-2 transition-all shadow-sm">
            <Sparkles className="w-4 h-4" />
            Generate
          </button>
          <button className="px-4 py-2 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white rounded-lg flex items-center gap-2 transition-all shadow-sm">
            <RefreshCw className="w-4 h-4" />
            Regenerate
          </button>
          <button className="px-4 py-2 bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white rounded-lg flex items-center gap-2 transition-all shadow-sm">
            <RotateCcw className="w-4 h-4" />
            Refine
          </button>
          <button className="px-4 py-2 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white rounded-lg flex items-center gap-2 transition-all shadow-sm">
            <Square className="w-3.5 h-3.5" />
            Stop
          </button>
          <button className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white rounded-lg flex items-center gap-2 transition-all shadow-sm">
            <Undo className="w-4 h-4" />
            Undo Last Change
          </button>
        </div>

        {/* Output Section */}
        <div className="space-y-2 pt-2">
          <label className="text-gray-900">Output (editable):</label>
          <textarea
            className="w-full h-24 px-3 py-2 border-2 border-gray-300 rounded-lg focus:border-indigo-500 focus:outline-none resize-none text-gray-700"
            placeholder="Draft summary appears here..."
          />
        </div>
      </div>
    </div>
  );
}
