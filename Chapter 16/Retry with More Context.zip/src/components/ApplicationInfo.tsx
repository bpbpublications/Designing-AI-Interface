export function ApplicationInfo() {
  return (
    <div className="border-b border-gray-400 px-6 py-2 flex items-center gap-8 bg-white">
      <span className="text-gray-800">APPLICATION: #L-784233</span>
      <span className="text-gray-800">STATUS: Needs Review</span>
    </div>
  );
}
