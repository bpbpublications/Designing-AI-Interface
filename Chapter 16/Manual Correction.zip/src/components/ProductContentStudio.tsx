import { useState } from 'react';
import { Sparkles } from 'lucide-react';

export function ProductContentStudio() {
  const [selectedFocus, setSelectedFocus] = useState<string>('');
  const [refinedIntent, setRefinedIntent] = useState('Make it persuasive but not pushy. Highlight eco features and bedtime comfort.');

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-lg border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="bg-indigo-600 px-6 py-3 flex items-center justify-between text-white">
        <h1>Product Content Studio</h1>
        <div className="flex items-center gap-2 bg-indigo-700 px-3 py-1.5 rounded">
          <span className="text-sm">Retail AI</span>
          <Sparkles size={16} />
        </div>
      </div>

      {/* Product & Prompt */}
      <div className="px-6 py-4 bg-blue-50 border-b border-gray-200">
        <div className="flex gap-6">
          <div>
            <div className="text-xs text-blue-700 mb-1">PRODUCT</div>
            <div className="text-gray-900">Aurora Night Lamp</div>
          </div>
          <div className="flex-1">
            <div className="text-xs text-blue-700 mb-1">USER PROMPT</div>
            <div className="text-gray-900">"Write a product description that sells it hard."</div>
          </div>
        </div>
      </div>

      {/* Clarification */}
      <div className="px-6 py-5 border-b border-gray-200">
        <div className="text-gray-900 mb-3">This instruction might be interpreted in many ways.</div>
        <div className="text-gray-700 mb-4">Did you mean:</div>
        
        <div className="space-y-3">
          <label className="flex items-start gap-3 cursor-pointer group">
            <input 
              type="radio" 
              name="focus" 
              value="emotional"
              checked={selectedFocus === 'emotional'}
              onChange={(e) => setSelectedFocus(e.target.value)}
              className="mt-0.5 w-4 h-4 accent-indigo-600"
            />
            <div className="flex-1 text-gray-800 group-hover:text-gray-900">
              Focus on emotional benefits (gift, mood, ambience)
            </div>
          </label>
          
          <label className="flex items-start gap-3 cursor-pointer group">
            <input 
              type="radio" 
              name="focus" 
              value="technical"
              checked={selectedFocus === 'technical'}
              onChange={(e) => setSelectedFocus(e.target.value)}
              className="mt-0.5 w-4 h-4 accent-indigo-600"
            />
            <div className="flex-1 text-gray-800 group-hover:text-gray-900">
              Focus on technical specs (lumens, battery, size)
            </div>
          </label>
          
          <label className="flex items-start gap-3 cursor-pointer group">
            <input 
              type="radio" 
              name="focus" 
              value="discounts"
              checked={selectedFocus === 'discounts'}
              onChange={(e) => setSelectedFocus(e.target.value)}
              className="mt-0.5 w-4 h-4 accent-indigo-600"
            />
            <div className="flex-1 text-gray-800 group-hover:text-gray-900">
              Focus on discounts and urgency
            </div>
          </label>
        </div>
      </div>

      {/* Refine Intent */}
      <div className="px-6 py-5 border-b border-gray-200">
        <label className="block">
          <div className="text-gray-700 mb-2">Or refine your intent:</div>
          <input 
            type="text"
            value={refinedIntent}
            onChange={(e) => setRefinedIntent(e.target.value)}
            className="w-full border border-gray-300 rounded px-3 py-2 text-gray-900 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
          />
        </label>
      </div>

      {/* Action Buttons */}
      <div className="px-6 py-4 border-b border-gray-200 flex items-center gap-3">
        <button className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 transition-colors">
          Reinterpret my input & regenerate copy
        </button>
        <button className="bg-white text-gray-700 px-4 py-2 rounded border border-gray-300 hover:bg-gray-50 transition-colors">
          Use original wording anyway
        </button>
      </div>

      {/* Quick Chips */}
      <div className="px-6 py-3 bg-gray-50 flex items-center gap-3">
        <span className="text-gray-600 text-sm">Quick chips:</span>
        <button className="bg-white text-gray-700 px-3 py-1 rounded-full border border-gray-300 text-sm hover:bg-gray-100 transition-colors">
          Softer tone
        </button>
        <button className="bg-white text-gray-700 px-3 py-1 rounded-full border border-gray-300 text-sm hover:bg-gray-100 transition-colors">
          More specs
        </button>
        <button className="bg-white text-gray-700 px-3 py-1 rounded-full border border-gray-300 text-sm hover:bg-gray-100 transition-colors">
          Kid-safe
        </button>
      </div>
    </div>
  );
}
