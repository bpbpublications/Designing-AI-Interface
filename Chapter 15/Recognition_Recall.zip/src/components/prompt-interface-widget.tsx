import { History, Lightbulb, MessageSquare } from 'lucide-react';
import { useState } from 'react';

export function PromptInterfaceWidget() {
  const [prompt, setPrompt] = useState('');

  const suggestions = [
    { id: 1, text: 'Summarize in 5 bullets', color: 'bg-blue-500' },
    { id: 2, text: 'Tone = friendly', color: 'bg-purple-500' },
    { id: 3, text: 'Translate to Hindi', color: 'bg-pink-500' },
    { id: 4, text: 'Extract action items', color: 'bg-emerald-500' },
    { id: 5, text: 'Compare Doc A vs Doc B', color: 'bg-amber-500' },
  ];

  const history = [
    'Create executive summary under 120 words',
    'Make a risks-only brief',
  ];

  const handleSuggestionClick = (text: string) => {
    setPrompt(text);
  };

  const handleHistoryClick = (text: string) => {
    setPrompt(text);
  };

  return (
    <div className="w-full max-w-3xl bg-white rounded-lg shadow-lg border border-gray-200">
      {/* Header */}
      <div className="px-4 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-t-lg flex items-center gap-3">
        <div className="w-8 h-8 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center">
          <MessageSquare className="w-4 h-4 text-white" />
        </div>
        <h2 className="text-white">AI Prompt Assistant</h2>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4">
        {/* What you can ask */}
        <div className="space-y-2">
          <label className="flex items-center gap-2 text-gray-700">
            <Lightbulb className="w-4 h-4 text-amber-500" />
            What you can ask:
          </label>
          <input
            type="text"
            className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none transition-colors"
            placeholder="Type your question or request..."
          />
        </div>

        {/* Suggestions */}
        <div className="space-y-2">
          <p className="text-gray-700">Suggestions:</p>
          <div className="flex flex-wrap gap-2">
            {suggestions.map((suggestion) => (
              <button
                key={suggestion.id}
                onClick={() => handleSuggestionClick(suggestion.text)}
                className={`px-3 py-1.5 ${suggestion.color} hover:opacity-90 text-white rounded-lg text-sm transition-all shadow-sm`}
              >
                [ {suggestion.text} ]
              </button>
            ))}
          </div>
        </div>

        {/* History */}
        <div className="space-y-2">
          <p className="flex items-center gap-2 text-gray-700">
            <History className="w-4 h-4 text-gray-500" />
            History (click to reuse):
          </p>
          <div className="bg-gray-50 rounded-lg p-3 space-y-2 border border-gray-200">
            {history.map((item, index) => (
              <button
                key={index}
                onClick={() => handleHistoryClick(item)}
                className="flex items-start gap-2 w-full text-left hover:bg-gray-100 p-2 rounded transition-colors"
              >
                <span className="text-gray-400 flex-shrink-0">•</span>
                <span className="text-gray-700">"{item}"</span>
              </button>
            ))}
          </div>
        </div>

        {/* Prompt Input */}
        <div className="space-y-2">
          <label className="text-gray-700">Prompt:</label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full h-20 px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none resize-none transition-colors"
            placeholder="[ ______________________________________________ ]"
          />
        </div>

        {/* Submit Button */}
        <div className="flex justify-end">
          <button className="px-6 py-2 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white rounded-lg transition-all shadow-sm">
            Submit
          </button>
        </div>
      </div>
    </div>
  );
}
