import { Undo, RotateCcw, Save, Plus, X } from 'lucide-react';

export function ActionBar() {
  return (
    <div className="border-t border-gray-200 p-4 bg-gray-50">
      <div className="flex items-center justify-between gap-3">
        {/* Left side - Undo actions */}
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-200 rounded transition-colors">
            <Undo size={18} />
            <span>Undo last AI edit</span>
          </button>
          <button className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-200 rounded transition-colors">
            <RotateCcw size={18} />
            <span>Undo my last change</span>
          </button>
        </div>

        {/* Right side - Primary actions */}
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-200 rounded transition-colors">
            <X size={18} />
            <span>Cancel</span>
          </button>
          <button className="flex items-center gap-2 px-4 py-2 text-[#1976d2] hover:bg-blue-50 rounded transition-colors">
            <Plus size={18} />
            <span>Add Diagnosis</span>
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-[#1976d2] text-white hover:bg-[#1565c0] rounded shadow-md transition-colors">
            <Save size={18} />
            <span>Save Note</span>
          </button>
        </div>
      </div>
    </div>
  );
}
