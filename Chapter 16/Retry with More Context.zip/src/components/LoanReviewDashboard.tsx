import { Sparkles } from 'lucide-react';
import { ApplicationInfo } from './ApplicationInfo';
import { AISuggestion } from './AISuggestion';
import { RetrySection } from './RetrySection';
import { ActionButtons } from './ActionButtons';

export function LoanReviewDashboard() {
  return (
    <div className="border border-gray-400 m-4">
      {/* Header */}
      <div className="border-b border-gray-400 px-6 py-3 flex items-center justify-between bg-white">
        <h1 className="text-gray-800">SME LOAN REVIEW DASHBOARD</h1>
        <div className="flex items-center gap-2">
          <span className="text-gray-800">Bank AI</span>
          <Sparkles size={16} className="text-yellow-600" />
        </div>
      </div>

      {/* Application Info */}
      <ApplicationInfo />

      {/* Main Content Grid - 2 columns */}
      <div className="grid grid-cols-2 border-t border-gray-400">
        {/* Left Column - AI Suggestion */}
        <div className="border-r border-gray-400">
          <AISuggestion />
        </div>

        {/* Right Column - Retry Section */}
        <div>
          <RetrySection />
        </div>
      </div>

      {/* Action Buttons */}
      <ActionButtons />
    </div>
  );
}
