import { ChevronRight, FileText, MessageCircle, ExternalLink } from 'lucide-react';
import { useState } from 'react';

export function SummaryReportWidget() {
  const [summaryExpanded, setSummaryExpanded] = useState(true);
  const [reportExpanded, setReportExpanded] = useState(false);

  return (
    <div className="w-full max-w-3xl bg-white rounded-lg shadow-lg border border-gray-200">
      {/* Header */}
      <div className="px-4 py-3 bg-gradient-to-r from-teal-500 to-cyan-600 rounded-t-lg flex items-center gap-3">
        <div className="w-8 h-8 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center">
          <FileText className="w-4 h-4 text-white" />
        </div>
        <h2 className="text-white">Q3 Report Summary</h2>
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        {/* Quick Summary Section */}
        <div className="border-2 border-gray-200 rounded-lg overflow-hidden">
          <button
            onClick={() => setSummaryExpanded(!summaryExpanded)}
            className="w-full px-4 py-2 bg-gray-50 hover:bg-gray-100 flex items-center gap-2 transition-colors"
          >
            <ChevronRight 
              className={`w-4 h-4 text-gray-600 transition-transform ${summaryExpanded ? 'rotate-90' : ''}`}
            />
            <span className="text-gray-900">Quick Summary (2 lines)</span>
          </button>
          
          {summaryExpanded && (
            <div className="px-4 py-3 space-y-3 border-t border-gray-200">
              <p className="text-gray-900">
                Q3 revenue <span className="text-emerald-600">+12%</span> QoQ; hiring <span className="text-purple-600">freeze</span> lowered OPEX <span className="text-rose-600">8%</span>. APAC expansion <span className="text-purple-600">is</span> primary.
              </p>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 flex-wrap">
                <button className="px-3 py-1.5 bg-blue-500 hover:bg-blue-600 text-white rounded text-sm transition-colors flex items-center gap-1.5">
                  <ExternalLink className="w-3.5 h-3.5" />
                  Show Sources
                </button>
                <button className="px-3 py-1.5 bg-indigo-500 hover:bg-indigo-600 text-white rounded text-sm transition-colors flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5" />
                  See Full Report
                </button>
                <button className="px-3 py-1.5 bg-purple-500 hover:bg-purple-600 text-white rounded text-sm transition-colors flex items-center gap-1.5">
                  <MessageCircle className="w-3.5 h-3.5" />
                  Ask Follow-up
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Full Report Section */}
        <div className="border-2 border-gray-200 rounded-lg overflow-hidden">
          <button
            onClick={() => setReportExpanded(!reportExpanded)}
            className="w-full px-4 py-2 bg-gray-50 hover:bg-gray-100 flex items-center gap-2 transition-colors"
          >
            <ChevronRight 
              className={`w-4 h-4 text-gray-600 transition-transform ${reportExpanded ? 'rotate-90' : ''}`}
            />
            <span className="text-gray-900">
              Full Report (collapsed) – click <span className="text-purple-600">to</span> expand <span className="text-purple-600">for</span> sections, charts, citations.
            </span>
          </button>
          
          {reportExpanded && (
            <div className="px-4 py-3 space-y-3 border-t border-gray-200">
              <div className="space-y-2">
                <h3 className="text-gray-900">Executive Summary</h3>
                <p className="text-gray-700">
                  Q3 demonstrated strong revenue growth of 12% quarter-over-quarter, primarily driven by expansion in the APAC region. Strategic cost management through a hiring freeze resulted in an 8% reduction in operational expenses.
                </p>
              </div>
              
              <div className="space-y-2">
                <h3 className="text-gray-900">Key Metrics</h3>
                <ul className="list-disc list-inside space-y-1 text-gray-700 pl-2">
                  <li>Revenue Growth: <span className="text-emerald-600">+12% QoQ</span></li>
                  <li>OPEX Reduction: <span className="text-rose-600">-8%</span></li>
                  <li>Regional Performance: APAC leading growth</li>
                </ul>
              </div>

              <div className="bg-blue-50 border-l-4 border-blue-500 rounded p-3">
                <p className="text-sm text-gray-700">
                  <span className="text-blue-700">📊 Charts & Citations:</span> Available in the detailed report document.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
