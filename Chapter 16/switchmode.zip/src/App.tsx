import { ContractDraftingWorkbench } from './components/ContractDraftingWorkbench';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <ContractDraftingWorkbench />
    </div>
  );
}
