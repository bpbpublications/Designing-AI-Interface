export function AISuggestion() {
  return (
    <div className="p-6 bg-white">
      <h2 className="text-gray-800 mb-3">AI SUGGESTION (INITIAL)</h2>
      
      <p className="text-gray-800 mb-3">
        "Recommend rejection due to insufficient revenue."
      </p>
      
      <div className="text-gray-600">
        ⚠ Reviewer flagged this as: [ TOO GENERIC ]
      </div>
    </div>
  );
}
