export function ActionButtons() {
  return (
    <div className="border-t border-gray-400 px-6 py-3 flex items-center gap-4 bg-white">
      <button className="px-4 py-2 border border-gray-400 text-gray-800 hover:bg-gray-100 transition-colors">
        [ Retry decision with added context ]
      </button>
      
      <button className="px-4 py-2 border border-gray-400 text-gray-800 hover:bg-gray-100 transition-colors">
        [ Keep my manual decision only ]
      </button>
    </div>
  );
}
