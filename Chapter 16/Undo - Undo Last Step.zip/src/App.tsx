import { PatientHeader } from './components/PatientHeader';
import { NotesEditor } from './components/NotesEditor';
import { ActionBar } from './components/ActionBar';

export default function App() {
  return (
    <div className="min-h-screen bg-[#f5f5f5]">
      <div className="max-w-4xl mx-auto p-6">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <PatientHeader 
            patientName="RAHUL MEHTA"
            visitDate="12 Dec 2025"
          />
          <NotesEditor />
          <ActionBar />
        </div>
      </div>
    </div>
  );
}
