import { TalentScreeningConsole } from './components/TalentScreeningConsole';

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-blue-50 to-pink-100 p-8">
      <TalentScreeningConsole />
    </div>
  );
}
