import { Check, ChevronDown } from 'lucide-react';

export function DraftSummaryWidget() {
  return (
    <div className="w-full max-w-3xl bg-white rounded-lg shadow-sm border border-gray-200">
      {/* Header */}
      <div className="px-4 py-2.5 border-b border-gray-200 flex items-center gap-2">
        <div className="w-5 h-5 bg-green-500 rounded flex items-center justify-center flex-shrink-0">
          <Check className="w-3.5 h-3.5 text-white" strokeWidth={3} />
        </div>
        <span className="text-gray-900">Draft <span className="text-rose-500">Summary</span></span>
      </div>

      {/* Content */}
      <div className="px-4 py-3 space-y-3">
        {/* Bullet Points */}
        <ul className="space-y-2 list-none">
          <li className="flex gap-2 text-gray-900">
            <span className="text-gray-400">•</span>
            <span>
              Revenue grew 12% QoQ, driven <span className="text-purple-600">by</span> APAC expansion.
            </span>
          </li>
          <li className="flex gap-2 text-gray-900">
            <span className="text-gray-400">•</span>
            <span>
              Hiring <span className="text-purple-600">freeze</span> reduced OPEX <span className="text-purple-600">by</span> 8%.
            </span>
          </li>
        </ul>

        {/* Explanation Section */}
        <div className="pt-2 space-y-1.5">
          <p className="text-gray-900">Why these points?</p>
          <div className="pl-4 border-l-2 border-gray-300 ml-1">
            <p className="text-gray-600 text-sm leading-relaxed">
              Suggested because <span className="text-purple-600">similar</span> phrasing appeared <span className="text-purple-600">in</span> prior meeting notes (Jun-12) <span className="text-purple-600">and</span> <span className="text-purple-600">in</span> paras 3–5 of Q3_Report.pdf.
            </p>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="px-4 py-3 border-t border-gray-200 bg-gray-50 flex items-center gap-2 flex-wrap">
        <button className="px-3 py-1.5 bg-white hover:bg-gray-50 border border-gray-300 text-gray-700 rounded text-sm transition-colors">
          Show Source Sentences
        </button>
        <button className="px-3 py-1.5 bg-white hover:bg-gray-50 border border-gray-300 text-gray-700 rounded text-sm transition-colors flex items-center gap-1">
          Change Tone
          <ChevronDown className="w-3.5 h-3.5" />
        </button>
        <button className="px-3 py-1.5 bg-white hover:bg-gray-50 border border-gray-300 text-gray-700 rounded text-sm transition-colors">
          Ask "why not X?"
        </button>
      </div>
    </div>
  );
}
